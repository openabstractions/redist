module github.com/openabstractions/websocket

go 1.12
