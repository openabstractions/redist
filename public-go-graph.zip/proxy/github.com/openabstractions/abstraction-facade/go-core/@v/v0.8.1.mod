module github.com/openabstractions/abstraction-facade/go-core

go 1.26.0

require github.com/openabstractions/abstraction-identity v0.8.1

require github.com/openabstractions/abstraction-storage/go v0.8.1

require golang.org/x/sys v0.47.0
