module github.com/openabstractions/abstraction-router/go

go 1.26.0

require (
	github.com/openabstractions/abstraction-facade/go-core v0.8.1
	github.com/openabstractions/abstraction-identity v0.8.1
	github.com/openabstractions/abstraction-model/identity v0.8.1
	github.com/openabstractions/abstraction-resource/go v0.8.1
	github.com/openabstractions/abstraction-rights/go v0.8.1
	github.com/openabstractions/abstraction-storage/go v0.8.1
)

require golang.org/x/sys v0.47.0

require (
	github.com/openabstractions/abstraction-cas/go v0.8.1 // indirect
	github.com/openabstractions/abstraction-job/go v0.8.1 // indirect
	github.com/openabstractions/abstraction-logging/go v0.8.1 // indirect
	github.com/openabstractions/abstraction-resource/go/platform v0.8.1 // indirect
	github.com/openabstractions/abstraction-watch/go v0.8.1 // indirect
)
